$(document).ready(function(){
    $(window).resize(function(){
        drawChart(getChartData());
      });
    var date1;
    var date2;
    var data;
      var chartData;
      var chart;
      var chartOptions;
      var options;
//     var arrdummy=[]
// for(var i=0;i<181;i++){
//     arrdummy.push([new Date(2019, 0, i+1), getRandomInt(1, 20),getRandomInt(10, 120),getRandomInt(70, 250)])
// }
//debugger;
//google.charts.load('current', {'packages':['corechart']});
//google.charts.setOnLoadCallback(function(){ drawChart(arr) });

  var aobj={};
  var pdata=[];
  var barray=[];
  var varray = [];
  var carray =[];
  var fpdata=[];
  //var purlarray = ["BRDAPI","BRDUI","CPS","DbaaS-Web-UI","DBaasAPI","DEBUT","GPSAPI","GPSUI","IAMAPI","IAMUI","ViewUi","RDASH2.5API","RDASH2.5UI"];
  var purlarray = ["BRDAPI","BRDUI","CPS","DbaaS-Web-UI","DEBUT","GPSAPI","GPSUI","IAMAPI","IAMUI","RDASH2.5API","RDASH2.5UI"];
  var purlarray1 = ["BRDAPI","RDASH2.5API"];
  for(var i=0;i<purlarray.length;i++){
    getJSON('assets/'+purlarray[i]+'.txt',  function(err, data) {
    
        if (err != null) {
            console.error(err);
        } else {
                    obj={};
          data.component.measures.map(function(obj){ aobj[obj.metric]=obj.value;aobj["name"]=data.component.name;aobj["key"]=data.component.key;} );          
          addRow(aobj);
          //console.log(JSON.stringify(aobj));
          //obj = aobj;
              //return server response as an object with JSON.parse                    
              // google.charts.setOnLoadCallback(drawStacked);
        }
          //checking all the checkboxes onload
        $("table input:checkbox").prop("checked", true);
        $('#headerch').on('click', function() {
            if (this.checked == true)
                $('table').find('input[type="checkbox"]').prop('checked', true);
            else
                $('table').find('input[type="checkbox"]').prop('checked', false);
        });

        $('#itable tr:has(td)').find('input[type="checkbox"]').click(function() {
            var isChecked = $(this).prop("checked");
            var isHeaderChecked = $("#headerch").prop("checked");
            if (isChecked == false && isHeaderChecked)
              $("#headerch").prop('checked', isChecked);
            else {
              $('#itable tr:has(td)').find('input[type="checkbox"]').each(function() {
                if ($(this).prop("checked") == false)
                  isChecked = false;
              });
              $("#headerch").prop('checked', isChecked);
            }
        })

    });
  }
  for(var i=0;i<purlarray.length;i++){
      getJSON('assets/SonarData/'+purlarray[i]+'.txt',  function(err, data) {
      
          if (err != null) {
              console.error(err);
          } else {
                      obj={};
            //data.component.measures.map(function(obj){ aobj[obj.metric]=obj.value;aobj["name"]=data.component.name;aobj["key"]=data.component.key;} );          
          //  data.measures.map(obj =>{pdata.push(obj.history);aobj[obj.metric]=obj.history[obj.history.unshift()-1].value})
            
           // addRow(aobj);
            nobj={};
            barray =[];carray=[];varray=[];
            for(issuearray of data.measures.slice()){
               
                if(barray.length==0 || carray.length==0 || varray.length==0){
                    if(issuearray.metric==="bugs"){                        
                        barray= barray.concat(issuearray.history);
                    }
                    if(issuearray.metric==="code_smells"){                        
                        carray = carray.concat(issuearray.history);
                    }
                    if(issuearray.metric==="vulnerabilities"){                        
                        varray =  varray.concat(issuearray.history);
                    }
                }else{

                }
              //  console.log(issuearray);
            }
            for(nobj of pdata){
                //console.log(nobj);
            }
           // console.log(JSON.stringify(aobj));
            //obj = aobj;
                //return server response as an object with JSON.parse                    
                // google.charts.setOnLoadCallback(drawStacked);
                var dataarray=[];var fbarray=[];var fvarray=[];var fcarray=[];

                for(var i=0;i<getdayscount()+1;i++){
                dataarray.push(new Date(2019, 0, i+1).toLocaleDateString())
                }
                var tempbarray =[];var tempvarray =[];var tempcarray =[];
                for(i=0;i<dataarray.length;i++){
                    tempbarray=[];
                    //for(var j=0;j<barray.length;j++){
                        //if(dataarray[i]==new Date(barray[j].date.slice(0,10)).toLocaleDateString()){
                            //tempbarray.push(barray[j]); 
                            tempbarray = barray.filter(function(obj){
                                if(dataarray[i]==new Date(obj.date.slice(0,10)).toLocaleDateString())
                                {     
                                    obj.value = Number(obj.value); 
                                    return obj;
                                }
                            })                               
                        //}
                    //}
                    if(tempbarray.length!=0){
                        fbarray.push(tempbarray[tempbarray.length-1]);
                    }else{
                        fbarray.push({date: new Date(dataarray[i]).toLocaleDateString(), value: Number(fbarray[fbarray.length-1].value)})
                    }
                    
                }
                createFinalbArray(fbarray);
                //------------------------------
                for(i=0;i<dataarray.length;i++){
                    tempvarray=[];
                    //for(var j=0;j<barray.length;j++){
                        //if(dataarray[i]==new Date(barray[j].date.slice(0,10)).toLocaleDateString()){
                            //tempbarray.push(barray[j]); 
                            tempvarray = varray.filter(function(obj){
                                if(dataarray[i]==new Date(obj.date.slice(0,10)).toLocaleDateString())
                                {     
                                    obj.value = Number(obj.value); 
                                    return obj;
                                }
                            })                               
                        //}
                    //}
                    if(tempvarray.length!=0){
                        fvarray.push(tempvarray[tempvarray.length-1]);
                    }else{
                        fvarray.push({date: new Date(dataarray[i]).toLocaleDateString(), value: Number(fvarray[fvarray.length-1].value)})
                    }
                    
                }
                createFinalvArray(fvarray);
                //-----------------------------------------------
                for(i=0;i<dataarray.length;i++){
                    tempcarray=[];
                    //for(var j=0;j<barray.length;j++){
                        //if(dataarray[i]==new Date(barray[j].date.slice(0,10)).toLocaleDateString()){
                            //tempbarray.push(barray[j]); 
                            tempcarray = carray.filter(function(obj){
                                if(dataarray[i]==new Date(obj.date.slice(0,10)).toLocaleDateString())
                                {     
                                    obj.value = Number(obj.value); 
                                    return obj;
                                }
                            })                               
                        //}
                    //}
                    if(tempcarray.length!=0){
                        fcarray.push(tempcarray[tempcarray.length-1]);
                    }else{
                        fcarray.push({date: new Date(dataarray[i]).toLocaleDateString(), value: Number(fcarray[fcarray.length-1].value)})
                    }
                    
                }
                createFinalcArray(fcarray);
            }
            google.charts.load('current', {
                callback: function () {
                  drawChart(getChartData());
                },
                packages: ['corechart']
              });
           // google.charts.setOnLoadCallback(function(){ drawChart(arr) });
           // google.charts.setOnLoadCallback(function(){ drawChart(getChartData()) });
      });
  }


  /*
  setTimeout(function(){       
      google.charts.load('current', {
          callback: function () {
  var obj ={Bugs:{Jan:230,Feb:140,March:260,April:430,May:330},Vulnerabilities:{Jan:900,Feb:860,March:920,April:1540,May:740},Code_smells:{Jan:4500,Feb:2500,March:3000,April:6000,May:4900},}                 
            drawChart(obj);
          },
          packages: ['corechart']
        });
    //google.charts.setOnLoadCallback(drawChart); 
    }, 50);*/
  
  var f_nm = 1;
  $("#nm").click(function(){
      f_nm *= -1;
      var n = $(this).prevAll().length;
      sortTable(f_nm,n);
  });
  
  //setting dates onload
  document.getElementById("idate1").value = "2019-01-01";
  var todayDate =(new Date().getYear()+1900).toString()+"-0"+ (new Date().getMonth()+1) +"-"+ new Date().getDate();
  document.getElementById("idate2").value = todayDate 
  document.getElementById("idate2").setAttribute("max", todayDate);

  function addRow(pobj){
    var newRow = 
   '<tr class="rowclass">'+
   '<td><input type="checkbox"></td>'+
    '<td><a href="#" onclick="someFunction(this);" id="'+pobj.key+'">'+pobj.name+'</a></td>'+
    '<td >'+pobj.bugs+'</td>'+
    '<td>'+pobj.vulnerabilities+'</td>'+
    '<td>'+pobj.code_smells+'</td>'+
    '</tr>'
     //$('#dtable tbody').append(newRow);				        
     //$('#dtable tbody tr:first').after(newRow);
     //$('#dtable tbody').find('tr:eq(1)').before(newRow)-
     $('#itable tr:last').after(newRow);
    //var attr= document.createAttribute("data-item").value=JSON.stringify(pobj);
    //  $('#itable tr:last')[0].setAttribute("data-item",JSON.stringify(pobj));
    //  $($('#itable tbody tr:first').children()[2])[0].innerHTML = Number($($('#itable tbody tr:first').children()[2])[0].innerHTML) + Number(pobj.bugs);
    //  $($('#itable tbody tr:first').children()[3])[0].innerHTML = Number($($('#itable tbody tr:first').children()[3])[0].innerHTML) + Number(pobj.vulnerabilities);
    //  $($('#itable tbody tr:first').children()[4])[0].innerHTML = Number($($('#itable tbody tr:first').children()[4])[0].innerHTML) + Number(pobj.code_smells);
  }
  
  })



  var allObj={};

function sortTable(f,n){
	var rows = $('#itable tbody  tr').get();

	rows.sort(function(a, b) {

		var A = getVal(a);
		var B = getVal(b);

		if(A < B) {
			return -1*f;
		}
		if(A > B) {
			return 1*f;
		}
		return 0;
	});

	function getVal(elm){
		var v = $(elm).children('td').eq(1).text().toUpperCase();
		if($.isNumeric(v)){
			v = parseInt(v,10);
		}
		return v;
	}

	$.each(rows, function(index, row) {
		$('#itable').children('tbody').append(row);
	});
}


function someFunction(e){    
    if($(e).text()=='All'){
        allObj["bugs"]=$($(e).closest('tr').children()[1]).text();
        allObj["vulnerabilities"]=$($(e).closest('tr').children()[2]).text();
        allObj["code_smells"]=$($(e).closest('tr').children()[3]).text();
        allObj["name"]= $(e).text();
        allObj["key"] = "projects";
       // console.log(allObj);
    }else{
       // console.log("fired : " + $(e).attr('id'));
        var dataItem = getDataItem($(e.closest('tr')));
       // console.log(dataItem);
    }
} 
function getDataItem(tr){       
  return JSON.parse(tr.attr('data-item'));
}






function getRandomInt(min, max) {
min = Math.ceil(min);
max = Math.floor(max);
return Math.floor(Math.random() * (max - min + 1)) + min;
}

function getdayscount(){
    var a = moment('1/1/2019', 'MM/DD/YYYY');
    //var b = moment('1/31/2019', 'MM/DD/YYYY');
    var b = moment(new Date().toLocaleDateString(), 'MM/DD/YYYY');
    return b.diff(a, 'days');
}

 var finalbarray=[];var finalvarray=[];var finalcarray=[];
function createFinalbArray(darray){
    if(finalbarray.length==0){
        finalbarray = finalbarray.concat(darray);
    }else{
        for(i=0;i<finalbarray.length;i++){
            for(var j=0;j<darray.length;j++){
                if(new Date(finalbarray[i].date.slice(0,10)).toLocaleDateString()==new Date(darray[j].date.slice(0,10)).toLocaleDateString()){                    
                    finalbarray[i].value = finalbarray[i].value + darray[j].value;
                    break;
                    // finalbarray = finalbarray.map(function(obj){
                    //     if(new Date(dataarray[i].date.slice(0,10)).toLocaleDateString()==new Date(obj.date.slice(0,10)).toLocaleDateString())
                    //     {                                    
                    //         return {date: new Date(obj.date).toLocaleDateString(), value: (+obj.value + +dataarray[i].value)};                        
                    //     }                    
                    // })                               
                }
            }

            
        }
    }
    console.log(finalbarray);

}
function createFinalvArray(darray){
    if(finalvarray.length==0){
        finalvarray = finalvarray.concat(darray);
    }else{
        for(i=0;i<finalvarray.length;i++){
            for(var j=0;j<darray.length;j++){
                if(new Date(finalvarray[i].date.slice(0,10)).toLocaleDateString()==new Date(darray[j].date.slice(0,10)).toLocaleDateString()){                    
                    finalvarray[i].value = finalvarray[i].value + darray[j].value;
                    break;
                    // finalbarray = finalbarray.map(function(obj){
                    //     if(new Date(dataarray[i].date.slice(0,10)).toLocaleDateString()==new Date(obj.date.slice(0,10)).toLocaleDateString())
                    //     {                                    
                    //         return {date: new Date(obj.date).toLocaleDateString(), value: (+obj.value + +dataarray[i].value)};                        
                    //     }                    
                    // })                               
                }
            }

            
        }
    }
  //  console.log(finalvarray);
}
function createFinalcArray(darray){
    if(finalcarray.length==0){
        finalcarray = finalcarray.concat(darray);
    }else{
        for(i=0;i<finalcarray.length;i++){
            for(var j=0;j<darray.length;j++){
                if(new Date(finalcarray[i].date.slice(0,10)).toLocaleDateString()==new Date(darray[j].date.slice(0,10)).toLocaleDateString()){                    
                    finalcarray[i].value = finalcarray[i].value + darray[j].value;
                    break;
                    // finalbarray = finalbarray.map(function(obj){
                    //     if(new Date(dataarray[i].date.slice(0,10)).toLocaleDateString()==new Date(obj.date.slice(0,10)).toLocaleDateString())
                    //     {                                    
                    //         return {date: new Date(obj.date).toLocaleDateString(), value: (+obj.value + +dataarray[i].value)};                        
                    //     }                    
                    // })                               
                }
            }

            
        }
    }
  //  console.log(finalcarray);
}
var finalChartArray =[];  var filterarr =[];
var date1 ="1/01/2019";
var date2 = new Date().toLocaleDateString();
function getChartData(){
    finalChartArray =[];
    filterarr =[];
    for(i=0;i<finalbarray.length;i++){
        finalChartArray.push([new Date(finalbarray[i].date.split('T')[0]),finalbarray[i].value ,finalvarray[i].value,finalcarray[i].value])
    }
 //   console.log(finalChartArray);
    var filterarr = finalChartArray.filter(function(arr){
        if(new Date(arr[0]) >= new Date(date1) && new Date(arr[0]) <= new Date(date2))
        {
        return arr;
        }
        })
        filterarr;
     //   console.log(filterarr); 
        getTicks();   
    return filterarr;
}
var ticksArray =[];var firstMonth;var lastMonth;
function getTicks(){
    ticksArray =[];
    firstMonth =  Number(date1.split('/')[0]);
    lastMonth =  Number(date2.split('/')[0]);
    ticksArray.push(new Date(date1));
    for(i=firstMonth;i<=lastMonth;i++){
        ticksArray.push(new Date((i+1).toString() +"/"+  date1.split('/')[1]+"/"+ date1.split('/')[2]));
    }    
}



function drawChart(arr) {
    data = new google.visualization.DataTable();
    data.addColumn('date', 'Month');
    data.addColumn('number', 'Bugs');
    data.addColumn('number', 'Vulnerabilities');
    data.addColumn('number', 'Code Smells');
    data.addRows(arr);
    console.log(arr);
    options = {
            title: 'Sonar Qube Issues',
            //width: 1030,
            width: '100%',
            colors:['#DC3545','#088EC6','#1D2939'],
            height: '90%',
            hAxis: {
            format: 'MMM y',
            gridlines: {color: 'grey'},
            title:'Month',titleTextStyle: {color: '#933'},
            //ticks:[arr[0][0],new Date(2019, 1, 1),new Date(2019, 2, 1),new Date(2019, 3, 1),new Date(2019, 4, 1),new Date(2019, 5, 1),new Date()]
            ticks:ticksArray
            },
            vAxis: {
            gridlines: {color: 'grey'},title:'Issues',titleTextStyle: {color: '#f33'},
            minValue: 0
            },
            // legend: { position: 'top', alignment: 'end', width: "10%" },
            legend: { position: 'none'},
                    explorer: { 
            //actions: ['dragToZoom', 'rightClickToReset'],

            axis: 'horizontal',
            keepInBounds: true,
            maxZoomIn: 4.0,
            maxZoomOut: 1.0},
            chartArea: {
                // adjust chart area size
                left: '10%',
                top: '5%',   
                height: '80%',
                width: '90%'
                //backgroundColor: 'magenta'
            }   
    };

     chart = new google.visualization.LineChart(document.getElementById('chart_div'));
    var columns = [];
    var series = {};
    for (var i = 0; i < data.getNumberOfColumns(); i++) {
    columns.push(i);
    if (i > 0) {
        series[i - 1] = {};
    }
    }

    google.visualization.events.addListener(chart, 'select', function () {
        var sel = chart.getSelection();
        // if selection length is 0, we deselected an element
        if (sel.length > 0) {
        // if row is undefined, we clicked on the legend
        if (sel[0].row === null) {
            var col = sel[0].column;
            if (columns[col] == col) {
                // hide the data series
                columns[col] = {
                    label: data.getColumnLabel(col),
                    type: data.getColumnType(col),
                    calc: function () {
                        return null;
                    }
                };

                // grey out the legend entry
                series[col - 1].color = '#CCCCCC';
            } else {
                // show the data series
                columns[col] = col;
                series[col - 1].color = null;
            }
            var view = new google.visualization.DataView(data);
            view.setColumns(columns);
            chart.draw(view, options);
        }
    }
    });

   
    
    chart.draw(data, options);
    chartData = data;
    chartOptions = options;

    //var button = document.getElementById('change');


    }


var getJSON = function(url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'json';    
    xhr.onload = function() {    
        var status = xhr.status;        
        if (status == 200) {
            callback(null, xhr.response);
        } else {
            callback(status);
        }
    };    
    xhr.send();
  };
function loadChart(){
    finalbarray=[];finalvarray=[];finalcarray=[];
     date1 = new Date(document.getElementById("idate1").value).toLocaleDateString();
     date2 = new Date(document.getElementById("idate2").value).toLocaleDateString();
    var keys = $('#itable tr:not(:first-child)').filter(':has(:checkbox:checked)').map(function() {
        var $tr = $(this);
        var key = $tr.find("td").eq("1").children().attr('id').split(':')[1];
        return key;
     }).toArray();
    // console.log(keys);
     if(keys.includes("AllProjects")){
        keys.shift();
     }

     for(var i=0;i<keys.length;i++){
        getJSON('assets/SonarData/'+keys[i]+'.txt',  function(err, data) {
        
            if (err != null) {
                console.error(err);
            } else {
                        obj={};
              //data.component.measures.map(function(obj){ aobj[obj.metric]=obj.value;aobj["name"]=data.component.name;aobj["key"]=data.component.key;} );          
            //  data.measures.map(obj =>{pdata.push(obj.history);aobj[obj.metric]=obj.history[obj.history.unshift()-1].value})
              
             // addRow(aobj);
              nobj={};
              barray =[];carray=[];varray=[];
              for(issuearray of data.measures.slice()){
                 
                  if(barray.length==0 || carray.length==0 || varray.length==0){
                      if(issuearray.metric==="bugs"){                        
                          barray= barray.concat(issuearray.history);
                      }
                      if(issuearray.metric==="code_smells"){                        
                          carray = carray.concat(issuearray.history);
                      }
                      if(issuearray.metric==="vulnerabilities"){                        
                          varray =  varray.concat(issuearray.history);
                      }
                  }else{
  
                  }
                //  console.log(issuearray);
              }

             // console.log(JSON.stringify(aobj));
              //obj = aobj;
                  //return server response as an object with JSON.parse                    
                  // google.charts.setOnLoadCallback(drawStacked);
                   dataarray=[]; fbarray=[]; fvarray=[]; fcarray=[];
  
                  for(var i=0;i<getdayscount()+1;i++){
                  dataarray.push(new Date(2019, 0, i+1).toLocaleDateString())
                  }
                   tempbarray =[]; tempvarray =[]; tempcarray =[];
                  for(i=0;i<dataarray.length;i++){
                      tempbarray=[];
                      //for(var j=0;j<barray.length;j++){
                          //if(dataarray[i]==new Date(barray[j].date.slice(0,10)).toLocaleDateString()){
                              //tempbarray.push(barray[j]); 
                              tempbarray = barray.filter(function(obj){
                                  if(dataarray[i]==new Date(obj.date.slice(0,10)).toLocaleDateString())
                                  {     
                                      obj.value = Number(obj.value); 
                                      return obj;
                                  }
                              })                               
                          //}
                      //}
                      if(tempbarray.length!=0){
                          fbarray.push(tempbarray[tempbarray.length-1]);
                      }else{
                          fbarray.push({date: new Date(dataarray[i]).toLocaleDateString(), value: Number(fbarray[fbarray.length-1].value)})
                      }
                      
                  }                  
                  createFinalbArray(fbarray);
                  //------------------------------
                  for(i=0;i<dataarray.length;i++){
                      tempvarray=[];
                      //for(var j=0;j<barray.length;j++){
                          //if(dataarray[i]==new Date(barray[j].date.slice(0,10)).toLocaleDateString()){
                              //tempbarray.push(barray[j]); 
                              tempvarray = varray.filter(function(obj){
                                  if(dataarray[i]==new Date(obj.date.slice(0,10)).toLocaleDateString())
                                  {     
                                      obj.value = Number(obj.value); 
                                      return obj;
                                  }
                              })                               
                          //}
                      //}
                      if(tempvarray.length!=0){
                          fvarray.push(tempvarray[tempvarray.length-1]);
                      }else{
                          fvarray.push({date: new Date(dataarray[i]).toLocaleDateString(), value: Number(fvarray[fvarray.length-1].value)})
                      }
                      
                  }
                  createFinalvArray(fvarray);
                  //-----------------------------------------------
                  for(i=0;i<dataarray.length;i++){
                      tempcarray=[];
                      //for(var j=0;j<barray.length;j++){
                          //if(dataarray[i]==new Date(barray[j].date.slice(0,10)).toLocaleDateString()){
                              //tempbarray.push(barray[j]); 
                              tempcarray = carray.filter(function(obj){
                                  if(dataarray[i]==new Date(obj.date.slice(0,10)).toLocaleDateString())
                                  {     
                                      obj.value = Number(obj.value); 
                                      return obj;
                                  }
                              })                               
                          //}
                      //}
                      if(tempcarray.length!=0){
                          fcarray.push(tempcarray[tempcarray.length-1]);
                      }else{
                          fcarray.push({date: new Date(dataarray[i]).toLocaleDateString(), value: Number(fcarray[fcarray.length-1].value)})
                      }
                      
                  }
                  createFinalcArray(fcarray);
              }
              google.charts.load('current', {
                  callback: function () {
                    drawChart(getChartData());
                  },
                  packages: ['corechart']
                });
             // google.charts.setOnLoadCallback(function(){ drawChart(arr) });
             // google.charts.setOnLoadCallback(function(){ drawChart(getChartData()) });
        });
    }
  
    
}
    var columns = [];
    var series = {};
    for (var i = 0; i < 4; i++) {
    columns.push(i);
    if (i > 0) {
        series[i - 1] = {};
    }
    }
 //--Using Checkboxes-----------------    
 function chartChange(selVal){
   

    var sel = [{row: null, column: selVal}];
    // if selection length is 0, we deselected an element
    if (sel.length > 0) {
    // if row is undefined, we clicked on the legend
    if (sel[0].row === null) {
        var col = sel[0].column;
        if (columns[col] == col) {
            // hide the data series
            columns[col] = {
                label: data.getColumnLabel(col),
                type: data.getColumnType(col),
                calc: function () {
                    return null;
                }
            };

            // grey out the legend entry
            series[col - 1].color = '#CCCCCC';
        } else {
            // show the data series
            columns[col] = col;
            series[col - 1].color = null;
        }
        var view = new google.visualization.DataView(data);
        view.setColumns(columns);
        chart.draw(view, options);
    }
}

}